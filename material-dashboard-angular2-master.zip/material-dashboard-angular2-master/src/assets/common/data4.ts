export function IncidentSeverityData4 (){
    let serviceData =[
        {
            "Incident_No":"INC00001254",
            "Severity": 1,
            "Service_queue":"Network Support",
            "Time_To_Breach":"3 Hours 30 minutes",
            "Color_Flag":2,
            "New_Flag":0,
            "Audio_Flag":0,
            "Assignee": ""
        }
    ];

     let getserviceData = () =>{
        return serviceData;
     };
     return {
        getserviceData:getserviceData
     }
};