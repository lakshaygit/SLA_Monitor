export function IncidentSeverityData3 (){
    let serviceData =[
        {
            "Incident_No":"IN0000C1254",
            "Severity": 1,
            "Service_queue":"Network Support",
            "Time_To_Breach":"15 Minutes",
            "Color_Flag":2,
            "New_Flag":0,
            "Audio_Flag":1,
            "Assignee": ""
        }
    ];

     let getserviceData3 = () =>{
        return serviceData;
     };
     return {
        getserviceData3:getserviceData3
     }
};
