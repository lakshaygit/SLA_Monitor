export function IncidentSeverityData15 (){
    let serviceData =[
        {
            "Incident_No":"INC00001254",
            "Severity": 1,
            "Service_queue":"Network Support",
            "Time_To_Breach":"-5 mins",
            "Color_Flag":3,
            "New_Flag":0,
            "Audio_Flag":1,
            "Assignee": "John Caley"
        },
        {
            "Incident_No":"IN0000C2345",
            "Severity": 2,
            "Service_queue":"Backup Support",
            "Time_To_Breach":"1 Hour 30 mins",
            "Color_Flag":2,
            "New_Flag":0,
            "Audio_Flag":1,
            "Assignee": ""
        },
        {
            "Incident_No":"IN0000C2999",
            "Severity": 3,
            "Service_queue":"Network Support",
            "Time_To_Breach":"4 Hours 30 mins",
            "Color_Flag":1,
            "New_Flag":0,
            "Audio_Flag":0,
            "Assignee": "Srikanth Aluru"
        }

    ];

     let getserviceData = () =>{
        return serviceData;
     };
     return {
        getserviceData:getserviceData
     }
};
