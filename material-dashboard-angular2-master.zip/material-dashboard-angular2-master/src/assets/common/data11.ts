export function IncidentSeverityData11 (){
    let serviceData =[
        {
            "Incident_No":"INC00001254",
            "Severity": 1,
            "Service_queue":"Network Support",
            "Time_To_Breach":"15 Minutes",
            "Color_Flag":2,
            "New_Flag":0,
            "Audio_Flag":1,
            "Assignee": "John Caley"
        },
        {
            "Incident_No":"IN0000C2345",
            "Severity": 2,
            "Service_queue":"Backup Support",
            "Time_To_Breach":"4 Hours 30 Minutes",
            "Color_Flag":2,
            "New_Flag":0,
            "Audio_Flag":0,
            "Assignee": ""
        },
        {
            "Incident_No":"IN0000C2999",
            "Severity": 3,
            "Service_queue":"Network Support",
            "Time_To_Breach":"1 day 4 Hours 1 Minute",
            "Color_Flag":0,
            "New_Flag":0,
            "Audio_Flag":0,
            "Assignee": ""
        }
    ];

     let getserviceData = () =>{
        return serviceData;
     };
     return {
        getserviceData:getserviceData
     }
};
