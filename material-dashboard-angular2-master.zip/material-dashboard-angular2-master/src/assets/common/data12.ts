export function IncidentSeverityData12 (){
    let serviceData =[
     
        {
            "Incident_No":"IN0000C2345",
            "Severity": 2,
            "Service_queue":"Backup Support",
            "Time_To_Breach":"10 Mins",
            "Color_Flag":2,
            "New_Flag":0,
            "Audio_Flag":0,
            "Assignee": ""
        },
        {
            "Incident_No":"IN0000C2999",
            "Severity": 3,
            "Service_queue":"Network Support",
            "Time_To_Breach":"20 Minute",
            "Color_Flag":0,
            "New_Flag":0,
            "Audio_Flag":0,
            "Assignee": ""
        }
    ];

     let getserviceData = () =>{
        return serviceData;
     };
     return {
        getserviceData:getserviceData
     }
};
