export function IncidentSeverityData1 (){
    let serviceData =[
        {
            "Incident_No":"IN0000C1254",
            "Severity": 1,
            "Service_queue":"Network Support",
            "Time_To_Breach":"40 Minutes",
            "Color_Flag":2,
            "New_Flag":1,
            "Audio_Flag":1,
            "Assignee": ""
        }
    ];

     let getserviceData = () =>{
        return serviceData;
     };
     return {
        getserviceData:getserviceData
     }
};
