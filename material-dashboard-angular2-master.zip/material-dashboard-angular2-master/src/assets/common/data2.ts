export function IncidentSeverityData2 (){
    let serviceData =[
        {
            "Incident_No":"INC00001254",
            "Severity": 1,
            "Service_queue":"Network Support",
            "Time_To_Breach":"4 Hours",
            "Color_Flag":2,
            "New_Flag":0,
            "Audio_Flag":0,
            "Assignee": ""
        }
    ];

     let getserviceData = () =>{
        return serviceData;
     };
     return {
        getserviceData:getserviceData
     }
};
