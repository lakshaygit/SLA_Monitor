export function IncidentSeverityData9 (){
    let serviceData =[
        {
            "Incident_No":"INC00001254",
            "Severity": 1,
            "Service_queue":"Network Support",
            "Time_To_Breach":"1 Hour",
            "Color_Flag":2,
            "New_Flag":0,
            "Audio_Flag":0,
            "Assignee": "John Caley"
        },
        {
            "Incident_No":"IN0000C2345",
            "Severity": 2,
            "Service_queue":"Backup Support",
            "Time_To_Breach":"7 Hours 30 Minutes",
            "Color_Flag":2,
            "New_Flag":0,
            "Audio_Flag":0,
            "Assignee": ""
        }
    ];

     let getserviceData = () =>{
        return serviceData;
     };
     return {
        getserviceData:getserviceData
     }
};
