export function IncidentSeverityData14 (){
    let serviceData =[
      
        {
            "Incident_No":"IN0000C2345",
            "Severity": 2,
            "Service_queue":"Backup Support",
            "Time_To_Breach":"5 Minutes",
            "Color_Flag":2,
            "New_Flag":0,
            "Audio_Flag":1,
            "Assignee": ""
        }

    ];

     let getserviceData = () =>{
        return serviceData;
     };
     return {
        getserviceData:getserviceData
     }
};
