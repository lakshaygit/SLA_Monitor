export function IncidentSeverityData7 (){
    let serviceData =[
        {
            "Incident_No":"IN0000C1254",
            "Severity": 1,
            "Service_queue":"Network Support",
            "Time_To_Breach":"2 Hours",
            "Color_Flag":2,
            "New_Flag":0,
            "Audio_Flag":1,
            "Assignee": "John Caley"
        }
    ];

     let getserviceData = () =>{
        return serviceData;
     };
     return {
        getserviceData:getserviceData
     }
};
