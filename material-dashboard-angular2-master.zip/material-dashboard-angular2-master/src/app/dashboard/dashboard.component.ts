import { Component, OnInit } from '@angular/core';
import * as Chartist from 'chartist';
import { IncidentSeverityData1 } from './../../assets/common/data';
import { IncidentSeverityData2 } from './../../assets/common/data2';
import { IncidentSeverityData3 } from './../../assets/common/data3';
import { IncidentSeverityData4 } from './../../assets/common/data4';
import { IncidentSeverityData5 } from './../../assets/common/data5';
import { IncidentSeverityData6 } from './../../assets/common/data6';
import { IncidentSeverityData7 } from './../../assets/common/data7';
import { IncidentSeverityData8 } from './../../assets/common/data8';
import { IncidentSeverityData9 } from './../../assets/common/data9';
import { IncidentSeverityData10 } from './../../assets/common/data10';
import { IncidentSeverityData11 } from './../../assets/common/data11';
import { IncidentSeverityData12 } from './../../assets/common/data12';
import { IncidentSeverityData13 } from './../../assets/common/data13';
import { IncidentSeverityData14 } from './../../assets/common/data14';
import { IncidentSeverityData15 } from './../../assets/common/data15';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  fileReaded: any;
  empName: any = [];
  empNumber: any = []
  totalIncidents: any = [];
  inProgressIncidents: any = [];
  globalDate: Date;
  data1: any;
  data2: any;
  data3: any;
  data4: any;
  data5: any;
  data6: any;
  data7: any;
  data8: any;
  data9: any;
  data10: any;
  data11: any;
  data12: any;
  data13: any;
  data14: any;
  data15: any;
  newNetworkIncidentFlag: boolean = false;
  newNetworkResponseCritical: boolean = false;
  newNetworkResponseCritical1: boolean = false;
  newNetworkResponseCritical2: boolean = false;
  newBackupResponseCritical: boolean = false;
  backupHigherCriticalResponse: boolean = false;
  networkSupportTeamSeverity3: boolean = false;
  backupSupportBreach:boolean = false;
  networkResolutionBreach: Boolean = false;
  higherCriticalResolution:boolean = false;
  backupSupportResponseBreach2: boolean = false;
  backupSupportResolutionBreach2: boolean = false;
  arrResponse: any = [];
  arrResolution: any = [];
  // flagForFunction2: boolean = false;
  constructor() {
    let incidentSeverityData1 = IncidentSeverityData1();
    let incidentSeverityData2 = IncidentSeverityData2();
    let incidentSeverityData3 = IncidentSeverityData3();
    let incidentSeverityData4 = IncidentSeverityData4();
    let incidentSeverityData5 = IncidentSeverityData5();
    let incidentSeverityData6 = IncidentSeverityData6();
    let incidentSeverityData7 = IncidentSeverityData7();
    let incidentSeverityData8 = IncidentSeverityData8();
    let incidentSeverityData9 = IncidentSeverityData9();
    let incidentSeverityData10 = IncidentSeverityData10();
    let incidentSeverityData11 = IncidentSeverityData11();
    let incidentSeverityData12 = IncidentSeverityData12();
    let incidentSeverityData13 = IncidentSeverityData13();
    let incidentSeverityData14 = IncidentSeverityData14();
    let incidentSeverityData15 = IncidentSeverityData15();

    this.data1 = incidentSeverityData1.getserviceData();
    this.data2 = incidentSeverityData2.getserviceData();
    this.data3 = incidentSeverityData3.getserviceData3();
    this.data4 = incidentSeverityData4.getserviceData();
    this.data5 = incidentSeverityData5.getserviceData();
    this.data6 = incidentSeverityData6.getserviceData();
    this.data7 = incidentSeverityData7.getserviceData();
    this.data8 = incidentSeverityData8.getserviceData();
    this.data9 = incidentSeverityData9.getserviceData();
    this.data10 = incidentSeverityData10.getserviceData();
    this.data11 = incidentSeverityData11.getserviceData();
    this.data12 = incidentSeverityData12.getserviceData();
    this.data13 = incidentSeverityData13.getserviceData();
    this.data14 = incidentSeverityData14.getserviceData();
    this.data15 = incidentSeverityData15.getserviceData();

  }
  startAnimationForLineChart(chart) {
    let seq: any, delays: any, durations: any;
    seq = 0;
    delays = 80;
    durations = 500;

    chart.on('draw', function (data) {
      if (data.type === 'line' || data.type === 'area') {
        data.element.animate({
          d: {
            begin: 600,
            dur: 700,
            from: data.path.clone().scale(1, 0).translate(0, data.chartRect.height()).stringify(),
            to: data.path.clone().stringify(),
            easing: Chartist.Svg.Easing.easeOutQuint
          }
        });
      } else if (data.type === 'point') {
        seq++;
        data.element.animate({
          opacity: {
            begin: seq * delays,
            dur: durations,
            from: 0,
            to: 1,
            easing: 'ease'
          }
        });
      }
    });

    seq = 0;
  };
  startAnimationForBarChart(chart) {
    let seq2: any, delays2: any, durations2: any;

    seq2 = 0;
    delays2 = 80;
    durations2 = 500;
    chart.on('draw', function (data) {
      if (data.type === 'bar') {
        seq2++;
        data.element.animate({
          opacity: {
            begin: seq2 * delays2,
            dur: durations2,
            from: 0,
            to: 1,
            easing: 'ease'
          }
        });
      }
    });

    seq2 = 0;
  };




  ngOnInit() {


    /* ----------==========    Incident Live Tracking    ==========---------- */

    var datawebsiteViewsChart = {
      labels: ['Network', 'Backup', 'Office 365', 'Window', 'Server'],
      series: [
        [20, 8,25, 5, 11],
        [2, 5, 10, 1, 0],
        [7, 4, 0, 10, 0]
      ]
    };
    var optionswebsiteViewsChart = {
      axisX: {
        showGrid: false
      },
      low: 2,
      high: 30,
      chartPadding: { top: 0, right: 5, bottom: 0, left: 0 }
    };
    var responsiveOptions: any[] = [
      ['screen and (max-width: 640px)', {
        seriesBarDistance: 5,
        axisX: {
          labelInterpolationFnc: function (value) {
            return value[0];
          }
        }
      }]
    ];
    var websiteViewsChart = new Chartist.Bar('#dailyIncidentLiveTrack', datawebsiteViewsChart, optionswebsiteViewsChart, responsiveOptions);

    //start animation for the Emails Subscription Chart
    this.startAnimationForBarChart(websiteViewsChart);


    /* ----------==========    Weekly Incident volume Trend as per Priority   ==========---------- */

   var datawebsiteViewsChart = {
      labels: ['Wk (0)', 'Wk(-1)', 'Wk(-2)', 'Wk(-3)'],
      series: [
       
        [4, 2, 20, 31],
        [2, 5, 1, 6],
        [20, 26, 17, 30]
      ]
    };
    var optionswebsiteViewsChart = {
      axisX: {
        showGrid: false
      },
      low: 2,
      high: 35,
      chartPadding: { top: 0, right: 5, bottom: 0, left: 0 }
    };
    var responsiveOptions: any[] = [
      ['screen and (max-width: 640px)', {
        seriesBarDistance: 5,
        axisX: {
          labelInterpolationFnc: function (value) {
            return value[0];
          }
        }
      }]
    ];
    var websiteViewsChart = new Chartist.Bar('#websiteViewsChart', datawebsiteViewsChart, optionswebsiteViewsChart, responsiveOptions);

    //start animation for the Emails Subscription Chart
    this.startAnimationForBarChart(websiteViewsChart);



    /* ----------==========     Aging/Backlog incident status   ==========---------- */

  

    var datawebsiteViewsChart = {
      labels: ['Network', 'Backup', 'Office 365', 'Window'],
      series: [
        [5, 2, 1, 0],
        [7, 3, 2, 0],
        [20, 5, 2, 1]
   
 
      ]
    };
    var optionswebsiteViewsChart = {
      axisX: {
        showGrid: false
      },
      low: 2,
      high: 25,
      chartPadding: { top: 0, right: 5, bottom: 0, left: 0 }
    };
    var responsiveOptions: any[] = [
      ['screen and (max-width: 640px)', {
        seriesBarDistance: 5,
        axisX: {
          labelInterpolationFnc: function (value) {
            return value[0];
          }
        }
      }]
    ];
    var websiteViewsChart = new Chartist.Bar('#completedTasksChart', datawebsiteViewsChart, optionswebsiteViewsChart, responsiveOptions);

    //start animation for the Emails Subscription Chart
    this.startAnimationForBarChart(websiteViewsChart);

    this.loggedTasksDataRead();

  }

  /**
   * Oninit Ends
   */
  loggedTasksDataRead() {


    (async () => {
     

      this.globalDate = new Date();
      this.arrResponse = this.data1;
      this.arrResolution = this.data2;
      this.newNetworkIncidentFlag = true;
      await this.delay(7000);
      this.newNetworkResponseCritical = true;

      await this.delay(30000);
  
 
      this.globalDate = new Date();
      this.arrResponse = this.data3;
      this.arrResolution = this.data4;
      this.newNetworkResponseCritical1 = true;

      await this.delay(30000);
      this.globalDate = new Date();
      this.arrResponse = this.data5;
      this.arrResolution = this.data6;
      this.newNetworkResponseCritical2 = true;


      await this.delay(30000);

      this.globalDate = new Date();
      this.arrResponse = this.data7;
      this.arrResolution = this.data7;

      await this.delay(30000);

      this.globalDate = new Date();
      this.arrResponse = this.data8;
      this.arrResolution = this.data9;
      this.newBackupResponseCritical = true;
      await this.delay(7000);
      this.backupHigherCriticalResponse = true;
      await this.delay(30000);
      this.globalDate = new Date();
      this.arrResponse = this.data10;
      this.arrResolution = this.data11;
      this.backupSupportBreach = true;
      await this.delay(7000);
      // netweork name used
      this.networkSupportTeamSeverity3 = true;
      await this.delay(9000);
      this.networkResolutionBreach = true;

      await this.delay(30000);
      this.globalDate = new Date();
      this.arrResponse = this.data12;
      this.arrResolution = this.data13;
      this.higherCriticalResolution = true;

      await this.delay(30000);
      this.globalDate = new Date();
      this.arrResponse = this.data14;
      this.arrResolution = this.data15;
      this.backupSupportResponseBreach2 = true;
      await this.delay(7000);
      this.backupSupportResolutionBreach2 = true;
    })();

  }




  /**
   *Function To Convert CSV to JSON 
   */
  csv2Array(fileInput: any) {
    //read file from input
    this.fileReaded = fileInput.target.files[0];

    let reader: FileReader = new FileReader();
    reader.readAsText(this.fileReaded);

    reader.onload = (e) => {
      let csv: any = reader.result;
      let allTextLines = csv.split(/\r|\n|\r/);
      let headers = allTextLines[0].split(',');
      let lines = [];


      for (let i = 0; i < allTextLines.length; i++) {
        // split content based on comma
        let data = allTextLines[i].split(',');
        if (data.length === headers.length) {
          let tarr = [];
          for (let j = 0; j < headers.length; j++) {
            console.log("DATA" + j + ":" + data[j]);
            tarr.push(data[j]);
          }

          // log each row to see output 

          lines.push(tarr);
        }
      }
      // all rows in the csv file 
      console.log(">>>>>>>>>>>>>>>>>", lines[1]);
      for (let i = 0; i < lines.length; i++) {
        this.empName[i] = lines[i][1];
        this.empNumber[i] = lines[i][2];

      }
      console.log([this.empNumber]);


      /* ----------==========     Daily Sales Chart initialization For Documentation    ==========---------- */

      // const dataDailySalesChartForEmp: any = {
      //   labels: [this.empName],
      //   series:
      //     [this.empNumber]

      // };

      // const optionsDailySalesChart: any = {
      //   lineSmooth: Chartist.Interpolation.cardinal({
      //     tension: 0
      //   }),
      //   low: 0,
      //   high: 100, // creative tim: we recommend you to set the high sa the biggest value + something for a better look
      //   chartPadding: { top: 0, right: 0, bottom: 0, left: 0 },
      // }

      // var dailySalesChart = new Chartist.Line('#dailySalesChart', dataDailySalesChartForEmp, optionsDailySalesChart);

      // this.startAnimationForLineChart(dailySalesChart);
    }
  }
  /**
  *Function To Convert CSV to JSON ENDS
  */
  /**
   * Method for async Delay
   */
  delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}
